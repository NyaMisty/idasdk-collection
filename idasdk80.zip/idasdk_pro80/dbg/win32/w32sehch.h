#ifndef __W32SEHCH__
#define __W32SEHCH__

void install_x86seh_menu();
void remove_x86seh_menu();

#endif
