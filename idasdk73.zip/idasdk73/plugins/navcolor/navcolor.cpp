/*
 *  This plugin demonstrates how to customize navigation band colors.
 *  Launch the plugin like so:
 *    - to install: ida_loader.load_and_run_plugin("navcolor", 1)
 *    - to uninstall: ida_loader.load_and_run_plugin("navcolor", 0)
 */

#include <ida.hpp>
#include <idp.hpp>
#include <loader.hpp>
#include <kernwin.hpp>

static bool installed = false;
static nav_colorizer_t *old_col_fun = NULL;
static void *old_col_ud = NULL;

//--------------------------------------------------------------------------
// Callback that calculates the pixel color given the address and the number of bytes
static uint32 idaapi my_colorizer(ea_t ea, asize_t nbytes, void *)
{
  // you are at your own here. just for the sake of illustrating how things work
  // we will invert all colors
  uint32 color = old_col_fun(ea, nbytes, old_col_ud);
  return ~color;
}

//-------------------------------------------------------------------------
static bool maybe_install()
{
  bool ok = !installed;
  if ( ok )
  {
    set_nav_colorizer(&old_col_fun, &old_col_ud, my_colorizer, NULL);
    installed = true;
  }
  return ok;
}

//-------------------------------------------------------------------------
static bool maybe_uninstall()
{
  bool ok = installed;
  if ( ok )
  {
    set_nav_colorizer(NULL, NULL, old_col_fun, old_col_ud);
    installed = false;
  }
  return ok;
}

//--------------------------------------------------------------------------
// initialize the plugin
static int idaapi init(void)
{
  // we always agree to work.
  // we must return PLUGIN_KEEP because we will install callbacks.
  // if we return PLUGIN_OK, the kernel may unload us at any time and this will
  // lead to crashes.
  return PLUGIN_KEEP;
}

//--------------------------------------------------------------------------
// initialize the plugin
static void idaapi term(void)
{
  // uninstall our callback for navigation band, otherwise ida will crash
  maybe_uninstall();
}

//--------------------------------------------------------------------------
static bool idaapi run(size_t code)
{
  return code == 1 ? maybe_install() : maybe_uninstall();
}

//--------------------------------------------------------------------------
plugin_t PLUGIN =
{
  IDP_INTERFACE_VERSION,
  0,
  init,                 // initialize
  term,                 // terminate. this pointer may be NULL.
  run,                  // invoke plugin
  NULL,                 // long comment about the plugin
  NULL,                 // multiline help about the plugin
  "Modify navigation band colors",// the preferred short name of the plugin
  NULL                  // the preferred hotkey to run the plugin
};
