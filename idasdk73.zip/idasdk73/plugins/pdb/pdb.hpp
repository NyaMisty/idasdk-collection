//
// Copyright (c) 2005-2019 Hex-Rays SA <support@hex-rays.com>
// ALL RIGHTS RESERVED.
//
#pragma once

#define PDB_NODE_NAME             "$ pdb"
#define PDB_DLLBASE_NODE_IDX       0
#define PDB_DLLNAME_NODE_IDX       0
#define PDB_LOADING_WIN32_DBG      1
#define PDB_TYPESONLY_NODE_IDX     2

enum pdb_callcode_t
{
  // user invoked 'load pdb' command, load pdb for the input file.
  // after invocation, result (boolean) is stored in: netnode(PDB_NODE_NAME).altval(PDB_DLLBASE_NODE_IDX)
  PDB_CC_USER = 0,
  // ida decided to call the plugin itself
  PDB_CC_IDA  = 1,
  // load additional pdb. This is semantically the same as
  // PDB_CC_USER (i.e., "File > Load file > PDB file..."), except
  // it won't ask the user for the data; rather it expects it in
  // netnode(PDB_NODE_NAME):
  //   load_addr: netnode(PDB_NODE_NAME).altval(PDB_DLLBASE_NODE_IDX)
  //   dll_name:  netnode(PDB_NODE_NAME).supstr(PDB_DLLNAME_NODE_IDX)
  PDB_CC_USER_WITH_DATA = 3,
  // load debug info from the COFF file
  // ida decided to call the plugin itself
  //   dbginfo_params_t: netnode(DBGINFO_PARAM_NODE_NAME).supval(DBGINFO_PARAMS_KEY)
  PDB_CC_IDA_COFF = 4,
};

//----------------------------------------------------------------------
struct pdb_signature_t
{
  uint32 guid[4]; // if all zeroes, then consider as non-existing
  uint32 sig;
  uint32 age;
  pdb_signature_t(void) { memset(this, 0, sizeof(*this)); }
};

//----------------------------------------------------------------------------
struct pdbargs_t
{
  qstring pdb_path;     // Path to PDB file.
  qstring input_path;   // Path to PE file with associated PDB.
  pdb_signature_t pdb_sign;
  qstring spath;
  ea_t loaded_base;
  void *user_data;
  uint32 flags;
#define PDBFLG_DBG_MODULE  0x01
#define PDBFLG_ONLY_TYPES  0x02
#define PDBFLG_EFD         0x04
#define PDBFLG_COFF_FILE   0x08

  pdbargs_t(void)
    : loaded_base(BADADDR),
      user_data(NULL),
      flags(0)
  {}

  // If true, we are in a debugging session and the file specified by
  // input_path is an additional module that has been loaded by the
  // debugger itself.
  bool is_dbg_module(void) const
  {
    return (flags & PDBFLG_DBG_MODULE) != 0;
  }
  // PDB?
  bool is_pdbfile(void) const { return (flags & PDBFLG_COFF_FILE) == 0; }

  const char *fname(void) const
  {
    return !pdb_path.empty() ? pdb_path.begin() : input_path.c_str();
  }
};
