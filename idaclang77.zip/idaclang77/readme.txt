This is the command-line version of the IDAClang plugin. It uses libclang to parse C++ source code and generate type libraries.

See the tutorial here:
  https://www.hex-rays.com/wp-content/static/tutorials/idaclang/idaclang_tutorial.html

Before using it, please copy the idaclang executable to the idabin/ directory of your IDA installation.
